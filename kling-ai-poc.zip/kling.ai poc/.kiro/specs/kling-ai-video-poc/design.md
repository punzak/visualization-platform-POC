# Design Document: Kling AI Video POC

## Overview

This system automates the generation of professional real estate property videos by orchestrating a multi-stage AI pipeline. Property photos uploaded to S3 are analyzed by AWS Bedrock (Claude 3.5 Sonnet), sequenced into a narrative story, converted to voiceover audio via ElevenLabs, and transformed into cinematic video clips via the Kling.ai API — all assembled into a final property showcase video.

The architecture is fully serverless, event-driven, and asynchronous. Each stage is decoupled via EventBridge, enabling independent scaling, retries, and observability. The system handles the inherent latency of AI video generation (minutes per clip) through webhook callbacks and Step Functions orchestration.

The POC targets a single property job as the unit of work: a set of property photos in → a finished MP4 video out, with a DynamoDB job record tracking state throughout the pipeline.

---

## Architecture

```mermaid
graph TD
    Client([Client / Upload]) -->|PUT images| S3_Input[S3 Input Bucket]
    S3_Input -->|S3 Event Notification| Lambda_IA[ImageAnalysisFunction]
    Lambda_IA -->|Invoke Claude 3.5 Sonnet| Bedrock[AWS Bedrock]
    Lambda_IA -->|Write image metadata| DynamoDB[(DynamoDB)]
    Lambda_IA -->|Emit all-images-analyzed event| EventBridge[EventBridge]

    EventBridge -->|Trigger| Lambda_SS[StorySequencingFunction]
    Lambda_SS -->|Read image metadata| DynamoDB
    Lambda_SS -->|Invoke Claude 3.5 Sonnet| Bedrock
    Lambda_SS -->|Write story + prompts| DynamoDB
    Lambda_SS -->|Emit story-generated event| EventBridge

    EventBridge -->|Trigger| Lambda_VG[VoiceoverGenerationFunction]
    Lambda_VG -->|Read script| DynamoDB
    Lambda_VG -->|Read API key| SecretsManager[Secrets Manager]
    Lambda_VG -->|POST text-to-speech| ElevenLabs[ElevenLabs API]
    Lambda_VG -->|Write MP3 to S3| S3_Assets[S3 Assets Bucket]
    Lambda_VG -->|Update job state| DynamoDB
    Lambda_VG -->|Emit voiceover-complete event| EventBridge

    EventBridge -->|Trigger| Lambda_KO[VideoGenerationOrchestratorFunction]
    Lambda_KO -->|Read story + image URLs| DynamoDB
    Lambda_KO -->|POST image-to-video| KlingAI[Kling.ai API v3.0]
    Lambda_KO -->|Store task_ids| DynamoDB

    KlingAI -->|POST webhook callback| APIGW[API Gateway]
    APIGW -->|Invoke| Lambda_WH[KlingWebhookHandlerFunction]
    Lambda_WH -->|Download video segment| S3_Assets
    Lambda_WH -->|Update segment state| DynamoDB
    Lambda_WH -->|All segments done?| EventBridge

    EventBridge -->|Trigger assembly| StepFunctions[Step Functions - Assembly]
    StepFunctions -->|Assemble final video| S3_Output[S3 Output Bucket]
    StepFunctions -->|Update job complete| DynamoDB

    SecretsManager -.->|API keys| Lambda_VG
    SecretsManager -.->|API keys| Lambda_KO
    CloudWatch[CloudWatch + X-Ray] -.->|Observability| Lambda_IA
    CloudWatch -.->|Observability| Lambda_SS
    CloudWatch -.->|Observability| Lambda_VG
    CloudWatch -.->|Observability| Lambda_KO
    CloudWatch -.->|Observability| Lambda_WH
```

---

## Sequence Diagrams

### Stage 1–2: Image Analysis → Story Sequencing

```mermaid
sequenceDiagram
    participant Client
    participant S3
    participant Lambda_IA as ImageAnalysisFunction
    participant Bedrock
    participant DynamoDB
    participant EventBridge

    Client->>S3: PUT property_photos/{job_id}/{image}.jpg
    S3->>Lambda_IA: S3 ObjectCreated event
    Lambda_IA->>Bedrock: InvokeModel (Claude 3.5 Sonnet + image bytes)
    Bedrock-->>Lambda_IA: ImageAnalysisResult JSON
    Lambda_IA->>DynamoDB: PutItem image metadata
    Lambda_IA->>DynamoDB: Check if all images analyzed
    alt All images analyzed
        Lambda_IA->>EventBridge: PutEvents all-images-analyzed
        EventBridge->>Lambda_SS: Trigger StorySequencingFunction
        Lambda_SS->>DynamoDB: GetItem all image metadata
        Lambda_SS->>Bedrock: InvokeModel story + prompts
        Bedrock-->>Lambda_SS: StorySequence JSON
        Lambda_SS->>DynamoDB: PutItem story sequence
        Lambda_SS->>EventBridge: PutEvents story-generated
    end
```

### Stage 3–4: Voiceover → Video Generation

```mermaid
sequenceDiagram
    participant EventBridge
    participant Lambda_VG as VoiceoverGenerationFunction
    participant SecretsManager
    participant ElevenLabs
    participant S3
    participant DynamoDB
    participant Lambda_KO as VideoGenerationOrchestrator
    participant KlingAI

    EventBridge->>Lambda_VG: story-generated event
    Lambda_VG->>DynamoDB: GetItem story script
    Lambda_VG->>SecretsManager: GetSecretValue elevenlabs_api_key
    Lambda_VG->>ElevenLabs: POST /v1/text-to-speech/{voice_id}
    ElevenLabs-->>Lambda_VG: audio/mpeg stream
    Lambda_VG->>S3: PutObject voiceover.mp3
    Lambda_VG->>DynamoDB: UpdateItem voiceover_s3_key
    Lambda_VG->>EventBridge: PutEvents voiceover-complete

    EventBridge->>Lambda_KO: voiceover-complete event
    Lambda_KO->>DynamoDB: GetItem story sequence + image URLs
    Lambda_KO->>SecretsManager: GetSecretValue kling_api_key
    loop For each image in sequence
        Lambda_KO->>KlingAI: POST /v1/video/generate
        KlingAI-->>Lambda_KO: {task_id, status: "queued"}
        Lambda_KO->>DynamoDB: UpdateItem segment task_id
    end
```

### Stage 5: Webhook Handling & Assembly

```mermaid
sequenceDiagram
    participant KlingAI
    participant APIGW as API Gateway
    participant Lambda_WH as KlingWebhookHandlerFunction
    participant S3
    participant DynamoDB
    participant EventBridge
    participant StepFunctions

    KlingAI->>APIGW: POST /webhook/kling {task_id, status, video_url}
    APIGW->>Lambda_WH: Invoke
    Lambda_WH->>Lambda_WH: Validate HMAC signature
    Lambda_WH->>S3: Download + store video segment
    Lambda_WH->>DynamoDB: UpdateItem segment status=complete
    Lambda_WH->>DynamoDB: Query all segments for job
    alt All segments complete
        Lambda_WH->>EventBridge: PutEvents all-segments-complete
        EventBridge->>StepFunctions: StartExecution assembly workflow
        StepFunctions->>S3: Assemble final video
        StepFunctions->>DynamoDB: UpdateItem job status=complete
    end
```

---

## Components and Interfaces

### Component 1: ImageAnalysisFunction

**Purpose**: Analyze each uploaded property photo using Claude 3.5 Sonnet vision to extract structured metadata.

**Interface**:
```python
def handler(event: dict, context: LambdaContext) -> dict:
    """
    Triggered by S3 ObjectCreated event.
    
    event: S3 event notification with Records[].s3.bucket.name and .object.key
    Returns: {"statusCode": 200, "body": "analyzed N images"}
    """

def analyze_image(s3_key: str, job_id: str) -> ImageAnalysisResult:
    """Download image from S3, invoke Bedrock, return structured metadata."""

def check_all_images_analyzed(job_id: str, expected_count: int) -> bool:
    """Query DynamoDB to determine if all images for a job have been analyzed."""

def emit_all_images_analyzed(job_id: str) -> None:
    """Put EventBridge event to trigger story sequencing."""
```

**Responsibilities**:
- Parse S3 event to extract job_id and image key
- Download image bytes from S3
- Invoke Claude 3.5 Sonnet with vision prompt
- Parse and validate Bedrock response into `ImageAnalysisResult`
- Write result to DynamoDB `images` table
- Check if all images for the job are analyzed; emit EventBridge event if so

---

### Component 2: StorySequencingFunction

**Purpose**: Determine optimal photo ordering and generate a 60–90 second narrative script with per-scene video prompts.

**Interface**:
```python
def handler(event: dict, context: LambdaContext) -> dict:
    """
    Triggered by EventBridge all-images-analyzed event.
    event.detail: {"job_id": str, "image_count": int}
    """

def sequence_images(image_metadata: list[ImageAnalysisResult]) -> StorySequence:
    """Invoke Bedrock to determine optimal ordering and generate script."""

def build_bedrock_prompt(image_metadata: list[ImageAnalysisResult]) -> str:
    """Construct the story sequencing prompt for Claude."""
```

**Responsibilities**:
- Retrieve all image metadata for the job from DynamoDB
- Invoke Claude 3.5 Sonnet with all metadata to generate story sequence
- Parse response into `StorySequence` with ordered images, script segments, and video prompts
- Write `StorySequence` to DynamoDB
- Emit `story-generated` EventBridge event

---

### Component 3: VoiceoverGenerationFunction

**Purpose**: Generate professional MP3 voiceover from the narrative script using ElevenLabs API.

**Interface**:
```python
def handler(event: dict, context: LambdaContext) -> dict:
    """
    Triggered by EventBridge story-generated event.
    event.detail: {"job_id": str}
    """

def generate_voiceover(script: str, voice_id: str, api_key: str) -> bytes:
    """Call ElevenLabs TTS API, return audio bytes."""

def upload_audio(audio_bytes: bytes, job_id: str) -> str:
    """Upload MP3 to S3, return s3_key."""
```

**Responsibilities**:
- Retrieve script from DynamoDB
- Fetch ElevenLabs API key from Secrets Manager
- POST to ElevenLabs `/v1/text-to-speech/{voice_id}` with Eleven Multilingual v2 model
- Upload resulting MP3 to S3 assets bucket
- Update DynamoDB job record with `voiceover_s3_key`
- Emit `voiceover-complete` EventBridge event

---

### Component 4: VideoGenerationOrchestratorFunction

**Purpose**: Submit each property image to Kling.ai API for image-to-video generation with cinematic camera movements.

**Interface**:
```python
def handler(event: dict, context: LambdaContext) -> dict:
    """
    Triggered by EventBridge voiceover-complete event.
    event.detail: {"job_id": str}
    """

def submit_video_task(image_url: str, prompt: str, job_id: str, 
                       segment_index: int, api_key: str) -> str:
    """POST to Kling.ai API, return task_id."""

def build_kling_payload(image_url: str, prompt: str, 
                         webhook_url: str) -> dict:
    """Construct Kling.ai API request payload."""
```

**Responsibilities**:
- Retrieve story sequence and presigned image URLs from DynamoDB/S3
- Fetch Kling.ai API key from Secrets Manager
- For each image in sequence: POST to `https://api.kling.ai/v1/video/generate`
- Store returned `task_id` per segment in DynamoDB
- Register webhook URL for callbacks

---

### Component 5: KlingWebhookHandlerFunction

**Purpose**: Receive Kling.ai completion callbacks, download video segments, and trigger final assembly when all segments are ready.

**Interface**:
```python
def handler(event: dict, context: LambdaContext) -> dict:
    """
    Triggered by API Gateway POST /webhook/kling.
    event.body: KlingWebhookPayload JSON
    Returns: {"statusCode": 200}
    """

def validate_webhook_signature(payload: str, signature: str, secret: str) -> bool:
    """Validate HMAC-SHA256 webhook signature."""

def download_video_segment(video_url: str, job_id: str, 
                            segment_index: int) -> str:
    """Download video from Kling CDN, upload to S3, return s3_key."""

def check_all_segments_complete(job_id: str) -> bool:
    """Query DynamoDB to check if all video segments are downloaded."""
```

**Responsibilities**:
- Parse and validate incoming webhook payload
- Validate HMAC signature to prevent spoofing
- Download completed video segment from Kling CDN
- Store segment in S3 assets bucket
- Update DynamoDB segment record to `status=complete`
- Check if all segments for the job are complete; emit `all-segments-complete` if so

---

## Data Models

### JobRecord (DynamoDB: `property-video-jobs`)

```python
@dataclass
class JobRecord:
    job_id: str                    # Partition key (UUID)
    status: str                    # queued | analyzing | sequencing | voiceover | generating | assembling | complete | failed
    created_at: str                # ISO 8601
    updated_at: str                # ISO 8601
    property_address: str          # Human-readable label
    image_count: int               # Total images expected
    images_analyzed: int           # Counter for completion check
    story_sequence_id: str         # FK to StorySequence item
    voiceover_s3_key: str          # S3 key for MP3
    final_video_s3_key: str        # S3 key for assembled MP4
    error_message: str             # Set on failure
    ttl: int                       # Unix epoch for DynamoDB TTL (30 days)
```

**Validation Rules**:
- `job_id` must be a valid UUID v4
- `status` must be one of the defined enum values
- `image_count` must be between 1 and 20
- `ttl` must be set on creation

---

### ImageAnalysisResult (DynamoDB: `property-video-images`)

```python
@dataclass
class ImageAnalysisResult:
    image_id: str                  # Partition key (UUID)
    job_id: str                    # GSI partition key
    s3_key: str                    # Original image S3 key
    sequence_index: int            # Assigned order (set by StorySequencing)
    room_type: str                 # e.g. "master_bedroom", "kitchen", "exterior"
    architectural_style: str       # e.g. "modern", "colonial", "craftsman"
    key_selling_points: list[str]  # e.g. ["natural light", "open plan", "hardwood floors"]
    lighting_quality: str          # "excellent" | "good" | "fair" | "poor"
    ambiance: str                  # e.g. "warm", "bright", "cozy"
    composition_score: float       # 0.0–1.0 Bedrock-assessed quality
    analysis_timestamp: str        # ISO 8601
```

**Validation Rules**:
- `composition_score` must be in range [0.0, 1.0]
- `key_selling_points` must have at least 1 item
- `room_type` must be a recognized enum value

---

### StorySequence (DynamoDB: `property-video-stories`)

```python
@dataclass
class SceneSegment:
    segment_index: int             # 0-based ordering
    image_id: str                  # FK to ImageAnalysisResult
    s3_key: str                    # Image S3 key
    script_text: str               # Voiceover text for this scene
    video_prompt: str              # Kling.ai generation prompt
    duration_seconds: int          # Target clip duration (3–10s)
    camera_movement: str           # e.g. "slow_zoom_in", "pan_right", "dolly_forward"
    kling_task_id: str             # Set after submission to Kling.ai
    kling_status: str              # queued | processing | complete | failed
    video_s3_key: str              # Set after webhook download

@dataclass
class StorySequence:
    story_id: str                  # Partition key (UUID)
    job_id: str                    # GSI partition key
    full_script: str               # Complete 60–90s narration
    total_duration_seconds: int    # Sum of segment durations
    segments: list[SceneSegment]   # Ordered scene list
    created_at: str                # ISO 8601
```

**Validation Rules**:
- `total_duration_seconds` must be between 60 and 90
- `segments` must be non-empty and match `image_count` on the job
- `camera_movement` must be a Kling.ai supported value

---

### KlingWebhookPayload

```python
@dataclass
class KlingWebhookPayload:
    task_id: str                   # Kling.ai task identifier
    status: str                    # "completed" | "failed"
    video_url: str                 # CDN URL for completed video (if status=completed)
    error_code: str                # Set if status=failed
    error_message: str             # Human-readable error
    duration_seconds: float        # Actual generated clip duration
    created_at: int                # Unix timestamp
```

---

## Algorithmic Pseudocode

### Main Algorithm: ImageAnalysisFunction

```python
ALGORITHM image_analysis_handler(s3_event, context)
INPUT:  s3_event — S3 ObjectCreated notification
OUTPUT: HTTP response dict

PRECONDITIONS:
  - s3_event.Records is non-empty
  - Each record has s3.bucket.name and s3.object.key
  - Lambda has s3:GetObject, bedrock:InvokeModel, dynamodb:PutItem permissions

POSTCONDITIONS:
  - ImageAnalysisResult written to DynamoDB for each processed image
  - If all images for job analyzed: EventBridge event emitted
  - Job status updated in DynamoDB

BEGIN
  FOR each record IN s3_event["Records"] DO
    # LOOP INVARIANT: all previously processed records have DynamoDB entries
    bucket = record["s3"]["bucket"]["name"]
    key    = record["s3"]["object"]["key"]
    
    # Extract job_id from key pattern: property_photos/{job_id}/{filename}
    job_id, filename = parse_s3_key(key)
    ASSERT job_id is valid UUID
    
    # Download image
    image_bytes = s3_client.get_object(Bucket=bucket, Key=key)["Body"].read()
    ASSERT len(image_bytes) <= 10 * 1024 * 1024  # 10MB max
    
    # Invoke Bedrock vision
    prompt = build_analysis_prompt(filename)
    response = bedrock_client.invoke_model(
        modelId="anthropic.claude-3-5-sonnet-20241022-v2:0",
        body=build_bedrock_request(prompt, image_bytes)
    )
    result = parse_analysis_response(response)
    ASSERT result.composition_score IN [0.0, 1.0]
    
    # Persist to DynamoDB
    dynamodb.put_item(table="property-video-images", item=result.to_dict())
    
    # Atomic counter increment and completion check
    updated_job = dynamodb.update_item(
        table="property-video-jobs",
        key={"job_id": job_id},
        update="SET images_analyzed = images_analyzed + 1",
        return_values="ALL_NEW"
    )
    
    IF updated_job["images_analyzed"] == updated_job["image_count"] THEN
      eventbridge.put_events(
        source="realestate.video.pipeline",
        detail_type="all-images-analyzed",
        detail={"job_id": job_id, "image_count": updated_job["image_count"]}
      )
    END IF
  END FOR
  
  RETURN {"statusCode": 200, "body": "OK"}
END
```

**Preconditions**: S3 key follows `property_photos/{uuid}/{filename}` pattern; image ≤ 10MB; job record exists in DynamoDB.
**Postconditions**: `images_analyzed` counter incremented atomically; `all-images-analyzed` event emitted exactly once when counter equals `image_count`.
**Loop Invariant**: All previously processed S3 records in the batch have a corresponding DynamoDB `ImageAnalysisResult` entry.

---

### Main Algorithm: StorySequencingFunction

```python
ALGORITHM story_sequencing_handler(event, context)
INPUT:  event — EventBridge event with detail.job_id
OUTPUT: HTTP response dict

PRECONDITIONS:
  - event.detail.job_id is a valid UUID
  - All ImageAnalysisResult records for job exist in DynamoDB
  - Lambda has dynamodb:Query, bedrock:InvokeModel permissions

POSTCONDITIONS:
  - StorySequence written to DynamoDB with ordered segments
  - Each segment has script_text, video_prompt, camera_movement
  - total_duration_seconds IN [60, 90]
  - story-generated EventBridge event emitted

BEGIN
  job_id = event["detail"]["job_id"]
  
  # Retrieve all image metadata
  images = dynamodb.query(
    table="property-video-images",
    index="job_id-index",
    key_condition="job_id = :job_id"
  )
  ASSERT len(images) > 0
  
  # Build sequencing prompt with all metadata
  prompt = build_story_prompt(images)
  
  # Invoke Bedrock for story generation
  response = bedrock_client.invoke_model(
    modelId="anthropic.claude-3-5-sonnet-20241022-v2:0",
    body={"messages": [{"role": "user", "content": prompt}],
          "max_tokens": 4096}
  )
  story = parse_story_response(response)
  
  ASSERT story.total_duration_seconds IN [60, 90]
  ASSERT len(story.segments) == len(images)
  
  FOR each segment IN story.segments DO
    # LOOP INVARIANT: all previous segments have valid camera_movement and prompt
    ASSERT segment.camera_movement IN VALID_CAMERA_MOVEMENTS
    ASSERT len(segment.script_text) > 0
    ASSERT len(segment.video_prompt) > 0
  END FOR
  
  # Persist story
  dynamodb.put_item(table="property-video-stories", item=story.to_dict())
  dynamodb.update_item(
    table="property-video-jobs",
    key={"job_id": job_id},
    update="SET status = :s, story_sequence_id = :sid",
    values={":s": "voiceover", ":sid": story.story_id}
  )
  
  eventbridge.put_events(
    source="realestate.video.pipeline",
    detail_type="story-generated",
    detail={"job_id": job_id, "story_id": story.story_id}
  )
  
  RETURN {"statusCode": 200}
END
```

**Preconditions**: All images analyzed; Bedrock model available; DynamoDB GSI on `job_id` exists.
**Postconditions**: `StorySequence` persisted; `total_duration_seconds` in [60, 90]; job status updated to `voiceover`.
**Loop Invariant**: All previously validated segments have non-empty `script_text`, `video_prompt`, and valid `camera_movement`.

---

### Main Algorithm: VoiceoverGenerationFunction

```python
ALGORITHM voiceover_generation_handler(event, context)
INPUT:  event — EventBridge event with detail.job_id
OUTPUT: HTTP response dict

PRECONDITIONS:
  - StorySequence exists in DynamoDB for job_id
  - ElevenLabs API key stored in Secrets Manager
  - Lambda has secretsmanager:GetSecretValue, s3:PutObject permissions

POSTCONDITIONS:
  - MP3 audio file stored in S3 assets bucket
  - DynamoDB job record updated with voiceover_s3_key
  - voiceover-complete EventBridge event emitted

BEGIN
  job_id = event["detail"]["job_id"]
  
  # Retrieve story
  story = dynamodb.get_item(table="property-video-stories", 
                             key={"job_id": job_id})
  ASSERT story.full_script is not None and len(story.full_script) > 0
  
  # Retrieve API key
  secret = secretsmanager.get_secret_value(SecretId="elevenlabs/api_key")
  api_key = json.loads(secret["SecretString"])["api_key"]
  voice_id = json.loads(secret["SecretString"])["voice_id"]
  
  # Call ElevenLabs TTS
  response = requests.post(
    url=f"https://api.elevenlabs.io/v1/text-to-speech/{voice_id}",
    headers={"xi-api-key": api_key, "Content-Type": "application/json"},
    json={
      "text": story.full_script,
      "model_id": "eleven_multilingual_v2",
      "voice_settings": {"stability": 0.5, "similarity_boost": 0.75}
    },
    timeout=90
  )
  ASSERT response.status_code == 200
  audio_bytes = response.content
  ASSERT len(audio_bytes) > 0
  
  # Upload to S3
  s3_key = f"voiceovers/{job_id}/narration.mp3"
  s3_client.put_object(
    Bucket=ASSETS_BUCKET, Key=s3_key,
    Body=audio_bytes, ContentType="audio/mpeg"
  )
  
  # Update job record
  dynamodb.update_item(
    table="property-video-jobs",
    key={"job_id": job_id},
    update="SET status = :s, voiceover_s3_key = :k",
    values={":s": "generating", ":k": s3_key}
  )
  
  eventbridge.put_events(
    source="realestate.video.pipeline",
    detail_type="voiceover-complete",
    detail={"job_id": job_id, "voiceover_s3_key": s3_key}
  )
  
  RETURN {"statusCode": 200}
END
```

**Preconditions**: `full_script` non-empty; ElevenLabs API key valid; S3 assets bucket writable.
**Postconditions**: MP3 stored at `voiceovers/{job_id}/narration.mp3`; job status = `generating`.

---

### Main Algorithm: VideoGenerationOrchestratorFunction

```python
ALGORITHM video_generation_handler(event, context)
INPUT:  event — EventBridge event with detail.job_id
OUTPUT: HTTP response dict

PRECONDITIONS:
  - StorySequence with segments exists for job_id
  - Kling.ai API key in Secrets Manager
  - Each segment has image_id, video_prompt, camera_movement, duration_seconds

POSTCONDITIONS:
  - Each segment has kling_task_id stored in DynamoDB
  - Each segment status = "queued"
  - All Kling.ai tasks submitted successfully

BEGIN
  job_id = event["detail"]["job_id"]
  
  story = get_story_sequence(job_id)
  api_key = get_kling_api_key()
  webhook_url = f"{API_GATEWAY_URL}/webhook/kling"
  
  FOR each segment IN story.segments DO
    # LOOP INVARIANT: all previously submitted segments have kling_task_id in DynamoDB
    image_url = generate_presigned_url(segment.s3_key, expires=3600)
    
    payload = {
      "image_url": image_url,
      "prompt": segment.video_prompt,
      "duration": segment.duration_seconds,
      "aspect_ratio": "16:9",
      "resolution": "1080p",
      "mode": "cinematic",
      "camera_movement": segment.camera_movement,
      "webhook_url": webhook_url
    }
    
    response = requests.post(
      url="https://api.kling.ai/v1/video/generate",
      headers={"Authorization": f"Bearer {api_key}",
               "Content-Type": "application/json"},
      json=payload,
      timeout=30
    )
    ASSERT response.status_code == 202
    task_id = response.json()["task_id"]
    ASSERT task_id is not None
    
    # Store task_id
    dynamodb.update_item(
      table="property-video-stories",
      key={"story_id": story.story_id, "segment_index": segment.segment_index},
      update="SET kling_task_id = :t, kling_status = :s",
      values={":t": task_id, ":s": "queued"}
    )
  END FOR
  
  RETURN {"statusCode": 200}
END
```

**Preconditions**: All segments have valid `video_prompt` and `camera_movement`; presigned URLs valid for ≥ 1 hour.
**Postconditions**: All segments have `kling_task_id`; status = `queued`.
**Loop Invariant**: All previously submitted segments have `kling_task_id` persisted in DynamoDB.

---

### Main Algorithm: KlingWebhookHandlerFunction

```python
ALGORITHM webhook_handler(event, context)
INPUT:  event — API Gateway proxy event with body=KlingWebhookPayload JSON
OUTPUT: {"statusCode": 200} or {"statusCode": 400}

PRECONDITIONS:
  - event.body is valid JSON
  - HMAC secret stored in Secrets Manager
  - Lambda has s3:PutObject, dynamodb:UpdateItem permissions

POSTCONDITIONS:
  - If status=completed: video segment stored in S3, DynamoDB updated
  - If all segments complete: all-segments-complete EventBridge event emitted
  - Returns 200 to acknowledge webhook (prevents Kling.ai retry)

BEGIN
  body = json.loads(event["body"])
  signature = event["headers"].get("X-Kling-Signature", "")
  
  # Validate signature
  secret = get_webhook_secret()
  expected = hmac.new(secret.encode(), event["body"].encode(), sha256).hexdigest()
  IF NOT hmac.compare_digest(expected, signature) THEN
    RETURN {"statusCode": 401, "body": "Invalid signature"}
  END IF
  
  task_id = body["task_id"]
  status  = body["status"]
  
  # Look up segment by task_id
  segment = dynamodb.query(
    table="property-video-stories",
    index="kling_task_id-index",
    key_condition="kling_task_id = :t"
  )[0]
  job_id = segment["job_id"]
  
  IF status == "completed" THEN
    video_url = body["video_url"]
    ASSERT video_url is not None
    
    # Download and store segment
    video_bytes = requests.get(video_url, timeout=25).content
    s3_key = f"segments/{job_id}/{segment['segment_index']}.mp4"
    s3_client.put_object(Bucket=ASSETS_BUCKET, Key=s3_key, Body=video_bytes)
    
    dynamodb.update_item(
      key={"story_id": segment["story_id"], 
           "segment_index": segment["segment_index"]},
      update="SET kling_status = :s, video_s3_key = :k",
      values={":s": "complete", ":k": s3_key}
    )
    
    # Check if all segments done
    IF check_all_segments_complete(job_id) THEN
      eventbridge.put_events(
        source="realestate.video.pipeline",
        detail_type="all-segments-complete",
        detail={"job_id": job_id}
      )
    END IF
    
  ELSE IF status == "failed" THEN
    dynamodb.update_item(
      update="SET kling_status = :s, error_message = :e",
      values={":s": "failed", ":e": body.get("error_message", "unknown")}
    )
    # Optionally trigger retry logic via EventBridge
  END IF
  
  RETURN {"statusCode": 200}
END
```

**Preconditions**: HMAC signature valid; `task_id` maps to a known segment; S3 assets bucket writable.
**Postconditions**: Segment status updated; video stored in S3 if completed; `all-segments-complete` emitted exactly once when all segments are done.

---

## Key Functions with Formal Specifications

### `parse_s3_key(key: str) -> tuple[str, str]`

```python
def parse_s3_key(key: str) -> tuple[str, str]:
    """
    Parse S3 object key into (job_id, filename).
    Expected format: property_photos/{job_id}/{filename}
    """
```

**Preconditions**:
- `key` is a non-empty string
- `key` matches pattern `property_photos/{uuid}/{filename}`

**Postconditions**:
- Returns `(job_id, filename)` where `job_id` is a valid UUID v4
- Raises `ValueError` if key does not match expected pattern

---

### `build_analysis_prompt(filename: str, image_b64: str) -> dict`

```python
def build_analysis_prompt(filename: str, image_b64: str) -> dict:
    """Build Bedrock InvokeModel request body for image analysis."""
```

**Preconditions**:
- `image_b64` is valid base64-encoded image data
- Image is JPEG, PNG, or WEBP format

**Postconditions**:
- Returns valid Bedrock `messages` API request body
- Prompt instructs Claude to return structured JSON with all `ImageAnalysisResult` fields
- Response schema included in prompt to enforce output format

---

### `check_all_segments_complete(job_id: str) -> bool`

```python
def check_all_segments_complete(job_id: str) -> bool:
    """
    Query DynamoDB to determine if all video segments for a job
    have kling_status = 'complete'.
    """
```

**Preconditions**:
- `job_id` is a valid UUID
- DynamoDB `property-video-stories` table has GSI on `job_id`

**Postconditions**:
- Returns `True` if and only if all segments have `kling_status = 'complete'`
- Returns `False` if any segment is `queued`, `processing`, or `failed`
- No mutations to any DynamoDB records

---

### `generate_presigned_url(s3_key: str, expires: int) -> str`

```python
def generate_presigned_url(s3_key: str, expires: int = 3600) -> str:
    """Generate a presigned S3 GET URL for Kling.ai to fetch the image."""
```

**Preconditions**:
- `s3_key` exists in the input S3 bucket
- `expires` is a positive integer (seconds), max 604800 (7 days)

**Postconditions**:
- Returns a valid HTTPS presigned URL
- URL is accessible without AWS credentials for `expires` seconds
- URL grants read-only access to the single specified object

---

## Example Usage

```python
# Example 1: Trigger a new job by uploading images
import boto3, uuid

job_id = str(uuid.uuid4())
s3 = boto3.client("s3")

# Upload 5 property photos — pipeline triggers automatically
for i, photo_path in enumerate(property_photos):
    with open(photo_path, "rb") as f:
        s3.put_object(
            Bucket="realestate-video-input",
            Key=f"property_photos/{job_id}/photo_{i:02d}.jpg",
            Body=f.read(),
            ContentType="image/jpeg"
        )

# Create job record before uploading (required for counter logic)
dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table("property-video-jobs")
table.put_item(Item={
    "job_id": job_id,
    "status": "analyzing",
    "image_count": len(property_photos),
    "images_analyzed": 0,
    "created_at": datetime.utcnow().isoformat(),
    "property_address": "123 Main St, Austin TX"
})

# Example 2: Poll job status
response = table.get_item(Key={"job_id": job_id})
job = response["Item"]
print(f"Status: {job['status']}")  # analyzing → sequencing → voiceover → generating → assembling → complete

# Example 3: Retrieve final video
if job["status"] == "complete":
    url = s3.generate_presigned_url(
        "get_object",
        Params={"Bucket": "realestate-video-output", "Key": job["final_video_s3_key"]},
        ExpiresIn=3600
    )
    print(f"Download video: {url}")

# Example 4: ElevenLabs API call (inside VoiceoverGenerationFunction)
import requests

response = requests.post(
    url=f"https://api.elevenlabs.io/v1/text-to-speech/{voice_id}",
    headers={"xi-api-key": api_key, "Content-Type": "application/json"},
    json={
        "text": "Welcome to this stunning modern home...",
        "model_id": "eleven_multilingual_v2",
        "voice_settings": {"stability": 0.5, "similarity_boost": 0.75}
    }
)
audio_bytes = response.content  # MP3 bytes

# Example 5: Kling.ai video generation call (inside VideoGenerationOrchestratorFunction)
response = requests.post(
    url="https://api.kling.ai/v1/video/generate",
    headers={"Authorization": f"Bearer {kling_api_key}"},
    json={
        "image_url": presigned_url,
        "prompt": "Slow cinematic dolly forward through bright open-plan kitchen, warm morning light",
        "duration": 5,
        "aspect_ratio": "16:9",
        "resolution": "1080p",
        "mode": "cinematic",
        "camera_movement": "dolly_forward",
        "webhook_url": "https://api.example.com/webhook/kling"
    }
)
task_id = response.json()["task_id"]
```

---

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system — essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Image Analysis Exactly-Once Completion Detection

For any job with `image_count` N, after exactly N `ImageAnalysisResult` records are written to DynamoDB, the `all-images-analyzed` EventBridge event SHALL be emitted exactly once — regardless of the order or concurrency of individual image analysis invocations.

**Validates: Requirements 2.7, 2.8**

---

### Property 2: Story Duration Constraint

For any `StorySequence` generated by the `StorySequencingFunction`, `total_duration_seconds` SHALL always be in the range [60, 90] inclusive.

**Validates: Requirements 3.3, 11.3**

---

### Property 3: Segment Count Matches Image Count

For any job with `image_count` N that has a corresponding `StorySequence`, the number of `SceneSegment` records in that `StorySequence` SHALL always equal N.

**Validates: Requirements 3.4**

---

### Property 4: Webhook Idempotency

For any valid `KlingWebhookPayload`, processing the same `task_id` payload more than once SHALL produce the same DynamoDB state as processing it once, and SHALL NOT emit duplicate `all-segments-complete` events.

**Validates: Requirements 6.10**

---

### Property 5: All-Segments-Complete Emitted Exactly Once

For any job, regardless of the order in which Kling.ai webhook callbacks arrive, the `all-segments-complete` EventBridge event SHALL be emitted exactly once when all segments reach `kling_status=complete`.

**Validates: Requirements 6.7**

---

### Property 6: Invalid Webhook Signatures Always Rejected

For any webhook payload where the `X-Kling-Signature` header does not match the HMAC-SHA256 of the payload body using the stored secret, the `KlingWebhookHandlerFunction` SHALL always return HTTP 401.

**Validates: Requirements 6.1, 6.2, 9.5**

---

### Property 7: Job Status Monotonicity

For any sequence of pipeline events applied to a `JobRecord`, the `status` field SHALL only advance forward through the sequence `analyzing → sequencing → voiceover → generating → assembling → complete`, and SHALL never regress to a prior state. Transition to `failed` is permitted from any state.

**Validates: Requirements 8.1, 8.2, 8.4**

---

### Property 8: S3 Key Pattern Validation

For any string that does not match the pattern `property_photos/{uuid-v4}/{filename}`, the `parse_s3_key` function SHALL always raise a `ValueError`.

**Validates: Requirements 1.4, 11.1**

---

### Property 9: Image Size Rejection

For any image whose byte size exceeds 10 MB (10 × 1024 × 1024 bytes), the `ImageAnalysisFunction` SHALL always reject it and halt processing for that record without invoking Bedrock.

**Validates: Requirements 2.2**

---

### Property 10: Composition Score Validation

For any `ImageAnalysisResult` where `composition_score` is outside the range [0.0, 1.0], the `ImageAnalysisFunction` SHALL always reject the result and not persist it to DynamoDB.

**Validates: Requirements 2.4**

---

### Property 11: Atomic Counter Correctness

For any set of concurrent Lambda invocations that each increment `images_analyzed` for the same `job_id`, the final value of `images_analyzed` in DynamoDB SHALL always equal the total number of successful increments, with no lost updates.

**Validates: Requirements 2.6, 10.7**

---

### Property 12: SceneSegment Field Completeness

For any `SceneSegment` produced by the `StorySequencingFunction`, the segment SHALL always have a non-empty `script_text`, a non-empty `video_prompt`, and a `camera_movement` value from the set of Kling.ai supported camera movements.

**Validates: Requirements 3.5, 11.4**

---

### Property 13: Kling.ai Payload Completeness

For any `SceneSegment` submitted by the `VideoGenerationOrchestratorFunction`, the POST payload to Kling.ai SHALL always contain `image_url`, `prompt`, `duration`, `aspect_ratio: 16:9`, `resolution: 1080p`, `mode: cinematic`, `camera_movement`, and `webhook_url`.

**Validates: Requirements 5.4**

---

### Property 14: All Segments Have Task IDs After Orchestration

For any `StorySequence` with N segments, after the `VideoGenerationOrchestratorFunction` completes, all N `SceneSegment` records SHALL have a non-null `kling_task_id` persisted in DynamoDB.

**Validates: Requirements 5.6**

---

### Property 15: Presigned URL Expiry Bounds

For any presigned S3 URL generated by the `VideoGenerationOrchestratorFunction`, the expiry SHALL always be at least 3600 seconds and at most 604800 seconds.

**Validates: Requirements 5.3, 11.5**

---

### Property 16: Segment S3 Key Naming Convention

For any completed Kling.ai webhook with a valid `job_id` and `segment_index`, the video segment SHALL always be stored in `S3_Assets` at the key `segments/{job_id}/{segment_index}.mp4`.

**Validates: Requirements 6.4**

---

### Property 17: Valid Webhook Always Returns HTTP 200

For any webhook payload that passes HMAC signature validation, the `KlingWebhookHandlerFunction` SHALL always return HTTP 200, regardless of the segment's completion status.

**Validates: Requirements 6.9**

---

### Property 18: Partial Batch Failure Reporting

For any S3 event batch containing one or more records that fail image analysis, the `ImageAnalysisFunction` SHALL always return a response using the `batchItemFailures` format, containing only the identifiers of the failed records.

**Validates: Requirements 10.5**

---

### Property 19: Structured Log Fields

For any Lambda function invocation in the pipeline, the emitted CloudWatch log entries SHALL always include `job_id`, the stage name, and the outcome of the operation.

**Validates: Requirements 10.2**

---

### Property 20: Unknown Task ID Rejection

For any Kling.ai webhook payload whose `task_id` does not map to a known `SceneSegment` in DynamoDB, the `KlingWebhookHandlerFunction` SHALL reject the request without modifying any DynamoDB records.

**Validates: Requirements 11.6**

---

## Error Handling

### Error Scenario 1: Bedrock Throttling / Timeout

**Condition**: Claude 3.5 Sonnet returns `ThrottlingException` or Lambda times out during `InvokeModel`.
**Response**: Lambda raises exception → SQS DLQ captures failed event → CloudWatch alarm triggers.
**Recovery**: EventBridge retry policy (3 retries with exponential backoff); failed jobs set `status=failed` with `error_message`.

---

### Error Scenario 2: ElevenLabs API Failure

**Condition**: ElevenLabs returns non-200 (rate limit, invalid voice_id, quota exceeded).
**Response**: Lambda logs error with `job_id` and status code; updates job `status=failed`.
**Recovery**: Operator can re-trigger `voiceover-complete` event manually after resolving quota issue.

---

### Error Scenario 3: Kling.ai Task Failure (Webhook `status=failed`)

**Condition**: Kling.ai cannot generate video for a segment (content policy, image quality, API error).
**Response**: Webhook handler sets segment `kling_status=failed`; emits `segment-failed` EventBridge event.
**Recovery**: Retry logic can re-submit the specific segment with a modified prompt; max 3 retries per segment.

---

### Error Scenario 4: Webhook Signature Mismatch

**Condition**: Incoming webhook has invalid or missing `X-Kling-Signature` header.
**Response**: Return HTTP 401 immediately; log warning with source IP.
**Recovery**: No action needed; legitimate Kling.ai callbacks will have valid signatures.

---

### Error Scenario 5: Partial Batch Failure (S3 → Lambda)

**Condition**: One image in a batch S3 event fails analysis (corrupt file, unsupported format).
**Response**: Lambda reports partial batch failure using `batchItemFailures` response; failed items returned to SQS for retry.
**Recovery**: S3 event source mapping retries failed items up to 3 times; after exhaustion, item goes to DLQ.

---

### Error Scenario 6: DynamoDB Conditional Write Conflict

**Condition**: Two Lambda invocations attempt to increment `images_analyzed` simultaneously.
**Response**: DynamoDB atomic `ADD` operation handles concurrent increments correctly; no lost updates.
**Recovery**: N/A — atomic counter operations are inherently safe.

---

## Testing Strategy

### Unit Testing Approach

Test each Lambda handler in isolation using `moto` for AWS service mocking and `pytest`.

Key unit test cases:
- `test_parse_s3_key_valid_format` — correct extraction of job_id and filename
- `test_parse_s3_key_invalid_format` — raises `ValueError` for malformed keys
- `test_analyze_image_bedrock_response_parsing` — correct mapping of Claude response to `ImageAnalysisResult`
- `test_story_duration_constraint` — story sequence always produces 60–90s total
- `test_webhook_signature_valid` — valid HMAC passes
- `test_webhook_signature_invalid` — invalid HMAC returns 401
- `test_check_all_segments_complete_true` — returns True when all segments complete
- `test_check_all_segments_complete_false` — returns False when any segment pending

### Property-Based Testing Approach

**Property Test Library**: `hypothesis`

```python
from hypothesis import given, strategies as st

@given(st.lists(st.builds(ImageAnalysisResult, ...), min_size=1, max_size=20))
def test_story_duration_always_in_range(images):
    story = sequence_images(images)
    assert 60 <= story.total_duration_seconds <= 90

@given(st.binary(min_size=1))
def test_webhook_invalid_signature_always_rejected(payload):
    event = build_webhook_event(payload, signature="invalid")
    result = webhook_handler(event, None)
    assert result["statusCode"] == 401

@given(st.text(min_size=1, max_size=5000))
def test_voiceover_script_accepted_by_elevenlabs_mock(script):
    # Any non-empty script should produce a valid API request
    request_body = build_elevenlabs_request(script, voice_id="test")
    assert request_body["text"] == script
    assert request_body["model_id"] in VALID_ELEVENLABS_MODELS
```

### Integration Testing Approach

- Deploy to a `dev` AWS environment with real Bedrock, mocked ElevenLabs and Kling.ai (via API Gateway mock integrations)
- End-to-end test: upload 3 test images → verify DynamoDB state transitions through all stages
- Webhook integration test: POST synthetic Kling.ai webhook payloads to API Gateway endpoint
- Step Functions execution test: verify assembly workflow completes and final video S3 key is set

---

## Performance Considerations

- **Image Analysis**: Bedrock `InvokeModel` latency ~2–5s per image; Lambda concurrency set to `image_count` for parallel processing
- **Story Sequencing**: Single Bedrock call with all metadata; ~5–10s; 90s Lambda timeout is sufficient
- **Voiceover Generation**: ElevenLabs TTS ~10–30s for 90s script; 120s Lambda timeout with buffer
- **Video Generation**: Kling.ai async (minutes per clip); webhook-driven — no Lambda timeout concern
- **S3 Presigned URLs**: Generated with 1-hour expiry; Kling.ai must fetch within this window
- **DynamoDB**: On-demand capacity mode for POC; GSIs on `job_id` and `kling_task_id` for efficient queries
- **Concurrency**: Up to 20 simultaneous Kling.ai tasks per job; Lambda reserved concurrency on webhook handler set to 50

---

## Security Considerations

- **API Keys**: All third-party API keys (ElevenLabs, Kling.ai) stored in AWS Secrets Manager; never in environment variables or code
- **Webhook Validation**: HMAC-SHA256 signature verification on all incoming Kling.ai webhooks; reject unsigned requests
- **IAM Least Privilege**: Each Lambda has a dedicated IAM role with only required permissions (no `*` actions)
- **S3 Bucket Policies**: Input, assets, and output buckets are private; no public access; presigned URLs for time-limited access
- **API Gateway**: Webhook endpoint uses AWS WAF for rate limiting and IP-based blocking
- **Secrets Rotation**: Secrets Manager rotation enabled for API keys (90-day rotation policy)
- **X-Ray Tracing**: Active tracing on all Lambdas; no PII in trace annotations
- **Input Validation**: Image format and size validated before Bedrock invocation; script length validated before ElevenLabs call

---

## Dependencies

| Dependency | Version | Purpose |
|---|---|---|
| AWS Bedrock (Claude 3.5 Sonnet) | `anthropic.claude-3-5-sonnet-20241022-v2:0` | Image analysis, story sequencing |
| ElevenLabs API | v1 | Text-to-speech voiceover generation |
| Kling.ai API | v3.0 | Image-to-video generation |
| AWS Lambda | Python 3.12 | Serverless compute for all stages |
| AWS S3 | — | Image input, asset storage, video output |
| AWS DynamoDB | — | Job state, image metadata, story sequences |
| AWS EventBridge | — | Stage-to-stage event routing |
| AWS Step Functions | — | Final video assembly orchestration |
| AWS API Gateway | — | Kling.ai webhook receiver |
| AWS Secrets Manager | — | API key storage |
| AWS CloudWatch + X-Ray | — | Observability and distributed tracing |
| `boto3` | ≥1.34 | AWS SDK for Python |
| `requests` | ≥2.31 | HTTP client for ElevenLabs and Kling.ai |
| `hypothesis` | ≥6.0 | Property-based testing |
| `pytest` | ≥7.0 | Unit testing framework |
| `moto` | ≥5.0 | AWS service mocking for tests |
