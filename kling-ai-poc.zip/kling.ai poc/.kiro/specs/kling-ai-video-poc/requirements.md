# Requirements Document

## Introduction

This document defines the functional requirements for the Kling AI Video POC — an automated, serverless pipeline that transforms real estate property photos into a finished MP4 showcase video. A client uploads property images to S3; the system analyzes each image with Claude 3.5 Sonnet, sequences them into a narrative story, generates a professional voiceover via ElevenLabs, submits each image to Kling.ai for cinematic video clip generation, and assembles all clips into a final video. A DynamoDB job record tracks state throughout the pipeline. The architecture is fully event-driven and asynchronous, with each stage decoupled via EventBridge.

---

## Glossary

- **Pipeline**: The end-to-end automated workflow from image upload to final video output.
- **Job**: A single unit of work representing one property's video generation run, identified by a UUID `job_id`.
- **JobRecord**: The DynamoDB record in `property-video-jobs` that tracks the status and metadata of a Job.
- **ImageAnalysisFunction**: The Lambda function that analyzes uploaded property images using Bedrock.
- **StorySequencingFunction**: The Lambda function that orders images and generates the narrative script and per-scene video prompts.
- **VoiceoverGenerationFunction**: The Lambda function that converts the narrative script to an MP3 via ElevenLabs.
- **VideoGenerationOrchestratorFunction**: The Lambda function that submits each image to Kling.ai for video clip generation.
- **KlingWebhookHandlerFunction**: The Lambda function that receives Kling.ai completion callbacks and triggers final assembly.
- **AssemblyWorkflow**: The Step Functions state machine that assembles individual video segments into the final MP4.
- **ImageAnalysisResult**: The structured metadata record produced by analyzing a single property image.
- **StorySequence**: The ordered list of scene segments with script text, video prompts, and camera movements.
- **SceneSegment**: A single scene within a StorySequence, corresponding to one property image and one Kling.ai video clip.
- **KlingWebhookPayload**: The JSON payload delivered by Kling.ai to the webhook endpoint upon task completion or failure.
- **Bedrock**: AWS Bedrock service used to invoke Claude 3.5 Sonnet for image analysis and story sequencing.
- **ElevenLabs**: Third-party text-to-speech API used to generate the property narration audio.
- **Kling.ai**: Third-party image-to-video API used to generate cinematic video clips from property images.
- **EventBridge**: AWS EventBridge used to route events between pipeline stages.
- **Secrets_Manager**: AWS Secrets Manager used to store and retrieve third-party API keys.
- **S3_Input**: The S3 bucket that receives uploaded property images.
- **S3_Assets**: The S3 bucket that stores intermediate assets (voiceover MP3, video segments).
- **S3_Output**: The S3 bucket that stores the final assembled MP4 video.
- **DynamoDB**: AWS DynamoDB used to persist job state, image metadata, and story sequences.
- **HMAC**: Hash-based Message Authentication Code used to validate Kling.ai webhook signatures.

---

## Requirements

### Requirement 1: Job Initialization

**User Story:** As a client, I want to initiate a video generation job by uploading property photos to S3, so that the pipeline starts automatically without manual intervention.

#### Acceptance Criteria

1. WHEN a client uploads one or more images to `S3_Input` under the key pattern `property_photos/{job_id}/{filename}`, THE `ImageAnalysisFunction` SHALL be triggered automatically via an S3 ObjectCreated event notification.
2. THE `Pipeline` SHALL require a `JobRecord` to exist in `DynamoDB` before image analysis begins, with `image_count` set to the total number of images expected for the job.
3. THE `JobRecord` SHALL be initialized with `status` set to `analyzing`, `images_analyzed` set to `0`, `created_at` set to the current ISO 8601 timestamp, and a `ttl` value set to 30 days from creation.
4. IF a `job_id` extracted from the S3 key is not a valid UUID v4, THEN THE `ImageAnalysisFunction` SHALL raise a `ValueError` and halt processing for that record.
5. THE `Pipeline` SHALL support between 1 and 20 images per job.

---

### Requirement 2: Image Analysis

**User Story:** As a system operator, I want each uploaded property image to be analyzed by Claude 3.5 Sonnet, so that structured metadata is extracted for use in story sequencing.

#### Acceptance Criteria

1. WHEN an S3 ObjectCreated event is received, THE `ImageAnalysisFunction` SHALL download the image bytes from `S3_Input` and invoke Bedrock with model `anthropic.claude-3-5-sonnet-20241022-v2:0`.
2. THE `ImageAnalysisFunction` SHALL reject any image whose size exceeds 10 MB and halt processing for that record.
3. WHEN Bedrock returns a response, THE `ImageAnalysisFunction` SHALL parse it into an `ImageAnalysisResult` containing `room_type`, `architectural_style`, `key_selling_points`, `lighting_quality`, `ambiance`, and `composition_score`.
4. THE `ImageAnalysisFunction` SHALL validate that `composition_score` is in the range [0.0, 1.0] and that `key_selling_points` contains at least one item.
5. WHEN an `ImageAnalysisResult` is validated, THE `ImageAnalysisFunction` SHALL write it to the `property-video-images` DynamoDB table.
6. WHEN an `ImageAnalysisResult` is written to DynamoDB, THE `ImageAnalysisFunction` SHALL atomically increment the `images_analyzed` counter on the `JobRecord`.
7. WHEN `images_analyzed` equals `image_count` on the `JobRecord`, THE `ImageAnalysisFunction` SHALL emit an `all-images-analyzed` event to EventBridge with `job_id` and `image_count` in the event detail.
8. THE `ImageAnalysisFunction` SHALL emit the `all-images-analyzed` event exactly once per job.
9. IF Bedrock returns a `ThrottlingException`, THEN THE `ImageAnalysisFunction` SHALL allow the Lambda invocation to fail so that the EventBridge retry policy (3 retries with exponential backoff) can recover the event.

---

### Requirement 3: Story Sequencing and Script Generation

**User Story:** As a system operator, I want the pipeline to determine the optimal image ordering and generate a narrative script with per-scene video prompts, so that the final video tells a coherent property story.

#### Acceptance Criteria

1. WHEN an `all-images-analyzed` EventBridge event is received, THE `StorySequencingFunction` SHALL query DynamoDB for all `ImageAnalysisResult` records associated with the `job_id`.
2. THE `StorySequencingFunction` SHALL invoke Bedrock with model `anthropic.claude-3-5-sonnet-20241022-v2:0` using all retrieved image metadata to generate a `StorySequence`.
3. WHEN Bedrock returns a `StorySequence`, THE `StorySequencingFunction` SHALL validate that `total_duration_seconds` is between 60 and 90 (inclusive).
4. THE `StorySequencingFunction` SHALL validate that the number of `SceneSegment` records in the `StorySequence` equals the `image_count` on the `JobRecord`.
5. THE `StorySequencingFunction` SHALL validate that each `SceneSegment` has a non-empty `script_text`, a non-empty `video_prompt`, and a `camera_movement` value from the set of Kling.ai supported camera movements.
6. WHEN the `StorySequence` is validated, THE `StorySequencingFunction` SHALL write it to the `property-video-stories` DynamoDB table.
7. WHEN the `StorySequence` is persisted, THE `StorySequencingFunction` SHALL update the `JobRecord` status to `voiceover` and set `story_sequence_id`.
8. WHEN the `JobRecord` is updated, THE `StorySequencingFunction` SHALL emit a `story-generated` EventBridge event with `job_id` and `story_id` in the event detail.

---

### Requirement 4: Voiceover Generation

**User Story:** As a system operator, I want the full narrative script to be converted to a professional MP3 voiceover, so that the final video has high-quality audio narration.

#### Acceptance Criteria

1. WHEN a `story-generated` EventBridge event is received, THE `VoiceoverGenerationFunction` SHALL retrieve the `StorySequence` from DynamoDB and extract `full_script`.
2. THE `VoiceoverGenerationFunction` SHALL retrieve the ElevenLabs API key and `voice_id` from `Secrets_Manager` using the secret ID `elevenlabs/api_key`.
3. WHEN the script and credentials are available, THE `VoiceoverGenerationFunction` SHALL POST to `https://api.elevenlabs.io/v1/text-to-speech/{voice_id}` with model `eleven_multilingual_v2` and voice settings `stability=0.5`, `similarity_boost=0.75`.
4. WHEN ElevenLabs returns a successful audio response, THE `VoiceoverGenerationFunction` SHALL upload the MP3 bytes to `S3_Assets` at key `voiceovers/{job_id}/narration.mp3` with `ContentType: audio/mpeg`.
5. WHEN the MP3 is stored in S3, THE `VoiceoverGenerationFunction` SHALL update the `JobRecord` with `voiceover_s3_key` and set `status` to `generating`.
6. WHEN the `JobRecord` is updated, THE `VoiceoverGenerationFunction` SHALL emit a `voiceover-complete` EventBridge event with `job_id` and `voiceover_s3_key` in the event detail.
7. IF ElevenLabs returns a non-200 HTTP response, THEN THE `VoiceoverGenerationFunction` SHALL log the error with `job_id` and status code, update the `JobRecord` `status` to `failed`, and halt processing.

---

### Requirement 5: Video Generation Orchestration

**User Story:** As a system operator, I want each property image to be submitted to Kling.ai for cinematic video clip generation, so that each scene in the story becomes an animated video segment.

#### Acceptance Criteria

1. WHEN a `voiceover-complete` EventBridge event is received, THE `VideoGenerationOrchestratorFunction` SHALL retrieve the `StorySequence` and presigned image URLs for all segments from DynamoDB and S3.
2. THE `VideoGenerationOrchestratorFunction` SHALL retrieve the Kling.ai API key from `Secrets_Manager`.
3. THE `VideoGenerationOrchestratorFunction` SHALL generate presigned S3 GET URLs for each segment image with an expiry of at least 3600 seconds.
4. FOR each `SceneSegment` in the `StorySequence`, THE `VideoGenerationOrchestratorFunction` SHALL POST to `https://api.kling.ai/v1/video/generate` with `image_url`, `prompt`, `duration`, `aspect_ratio: 16:9`, `resolution: 1080p`, `mode: cinematic`, `camera_movement`, and `webhook_url`.
5. WHEN Kling.ai returns HTTP 202 with a `task_id`, THE `VideoGenerationOrchestratorFunction` SHALL store the `task_id` and set `kling_status` to `queued` for that `SceneSegment` in DynamoDB.
6. THE `VideoGenerationOrchestratorFunction` SHALL persist a `kling_task_id` for every `SceneSegment` before the function returns.

---

### Requirement 6: Webhook Handling and Segment Storage

**User Story:** As a system operator, I want Kling.ai completion callbacks to be securely received and processed, so that completed video segments are stored and the pipeline can proceed to assembly.

#### Acceptance Criteria

1. WHEN a POST request is received at the `/webhook/kling` API Gateway endpoint, THE `KlingWebhookHandlerFunction` SHALL validate the HMAC-SHA256 signature in the `X-Kling-Signature` header against the webhook secret stored in `Secrets_Manager`.
2. IF the HMAC signature is invalid or missing, THEN THE `KlingWebhookHandlerFunction` SHALL return HTTP 401 and log a warning with the source IP.
3. WHEN the signature is valid and `KlingWebhookPayload.status` is `completed`, THE `KlingWebhookHandlerFunction` SHALL download the video bytes from the `video_url` in the payload.
4. WHEN the video bytes are downloaded, THE `KlingWebhookHandlerFunction` SHALL upload them to `S3_Assets` at key `segments/{job_id}/{segment_index}.mp4`.
5. WHEN the segment is stored in S3, THE `KlingWebhookHandlerFunction` SHALL update the `SceneSegment` in DynamoDB with `kling_status=complete` and `video_s3_key`.
6. WHEN the `SceneSegment` is updated, THE `KlingWebhookHandlerFunction` SHALL query DynamoDB to determine whether all segments for the job have `kling_status=complete`.
7. WHEN all segments are complete, THE `KlingWebhookHandlerFunction` SHALL emit an `all-segments-complete` EventBridge event with `job_id` exactly once per job.
8. IF `KlingWebhookPayload.status` is `failed`, THEN THE `KlingWebhookHandlerFunction` SHALL update the `SceneSegment` `kling_status` to `failed` and record the `error_message` in DynamoDB.
9. THE `KlingWebhookHandlerFunction` SHALL return HTTP 200 to acknowledge every valid webhook, regardless of segment status, to prevent Kling.ai retries.
10. THE `KlingWebhookHandlerFunction` SHALL be idempotent: processing the same `task_id` webhook payload more than once SHALL produce the same DynamoDB state and SHALL NOT emit duplicate `all-segments-complete` events.

---

### Requirement 7: Video Assembly

**User Story:** As a system operator, I want all completed video segments to be assembled into a single final MP4, so that the client receives a complete property showcase video.

#### Acceptance Criteria

1. WHEN an `all-segments-complete` EventBridge event is received, THE `AssemblyWorkflow` SHALL be started via Step Functions `StartExecution`.
2. WHEN the `AssemblyWorkflow` executes, THE `AssemblyWorkflow` SHALL retrieve all segment S3 keys for the job from DynamoDB in `segment_index` order.
3. WHEN all segments are retrieved, THE `AssemblyWorkflow` SHALL assemble them into a single MP4 and store the result in `S3_Output`.
4. WHEN the final video is stored, THE `AssemblyWorkflow` SHALL update the `JobRecord` `status` to `complete` and set `final_video_s3_key`.
5. IF the assembly process fails, THEN THE `AssemblyWorkflow` SHALL update the `JobRecord` `status` to `failed` and set `error_message`.

---

### Requirement 8: Job State Management

**User Story:** As a system operator, I want the job status to advance monotonically through the pipeline stages, so that I can reliably track progress and detect failures.

#### Acceptance Criteria

1. THE `JobRecord` `status` field SHALL only transition through the sequence: `analyzing` → `sequencing` → `voiceover` → `generating` → `assembling` → `complete`.
2. THE `Pipeline` SHALL allow any `status` to transition to `failed` at any stage.
3. WHEN a stage completes successfully, THE responsible Lambda SHALL update the `JobRecord` `status` to the next valid state before emitting the downstream EventBridge event.
4. THE `Pipeline` SHALL never regress a `JobRecord` `status` to a prior state.
5. WHEN a client queries the `JobRecord` by `job_id`, THE `DynamoDB` SHALL return the current `status`, `updated_at`, and any `error_message`.

---

### Requirement 9: Security and Credential Management

**User Story:** As a security engineer, I want all third-party API keys and webhook secrets to be stored and accessed securely, so that credentials are never exposed in code, logs, or environment variables.

#### Acceptance Criteria

1. THE `Pipeline` SHALL store all third-party API keys (ElevenLabs, Kling.ai) and the webhook HMAC secret exclusively in `Secrets_Manager`.
2. THE `Pipeline` SHALL never write API keys or secrets to Lambda environment variables, CloudWatch logs, or X-Ray trace annotations.
3. EACH Lambda function SHALL operate under a dedicated IAM role with only the permissions required for its specific operations.
4. THE `S3_Input`, `S3_Assets`, and `S3_Output` buckets SHALL have all public access blocked; access SHALL be granted only via presigned URLs or IAM roles.
5. THE `Pipeline` SHALL validate the HMAC-SHA256 signature on every incoming Kling.ai webhook before processing the payload.
6. WHERE the Kling.ai webhook endpoint is exposed via API Gateway, THE `Pipeline` SHALL apply AWS WAF rules for rate limiting and IP-based blocking.
7. THE `Secrets_Manager` SHALL have a 90-day rotation policy enabled for all stored API keys.

---

### Requirement 10: Observability and Error Recovery

**User Story:** As a system operator, I want comprehensive logging, tracing, and error handling across all pipeline stages, so that I can diagnose failures and recover jobs without data loss.

#### Acceptance Criteria

1. THE `Pipeline` SHALL enable AWS X-Ray active tracing on all Lambda functions.
2. THE `Pipeline` SHALL emit structured CloudWatch logs from each Lambda function including `job_id`, stage name, and outcome.
3. WHEN a Lambda function fails due to a transient error (e.g., Bedrock throttling), THE `Pipeline` SHALL retry the event up to 3 times with exponential backoff via the EventBridge retry policy.
4. WHEN a Lambda function exhausts all retries, THE `Pipeline` SHALL route the failed event to a Dead Letter Queue (DLQ) and trigger a CloudWatch alarm.
5. WHEN a batch S3 event contains a record that fails image analysis (e.g., corrupt file, unsupported format), THE `ImageAnalysisFunction` SHALL report a partial batch failure using the `batchItemFailures` response format so that only the failed record is retried.
6. WHEN a Kling.ai segment task fails (webhook `status=failed`), THE `Pipeline` SHALL allow the segment to be re-submitted with a modified prompt, up to 3 retries per segment.
7. IF two Lambda invocations attempt to increment `images_analyzed` concurrently, THEN THE `DynamoDB` SHALL use an atomic `ADD` operation to ensure no counter updates are lost.

---

### Requirement 11: Data Validation and Integrity

**User Story:** As a system operator, I want all data models to be validated at each pipeline stage, so that invalid data does not propagate and corrupt downstream stages.

#### Acceptance Criteria

1. THE `ImageAnalysisFunction` SHALL validate that each S3 key matches the pattern `property_photos/{uuid}/{filename}` before processing; IF the pattern does not match, THEN THE `ImageAnalysisFunction` SHALL raise a `ValueError`.
2. THE `ImageAnalysisFunction` SHALL validate that the image format is JPEG, PNG, or WEBP before invoking Bedrock.
3. THE `StorySequencingFunction` SHALL validate that `total_duration_seconds` is in [60, 90] before persisting the `StorySequence`.
4. THE `StorySequencingFunction` SHALL validate that each `SceneSegment` `camera_movement` is a value supported by the Kling.ai API before submitting video generation tasks.
5. THE `VideoGenerationOrchestratorFunction` SHALL validate that presigned URLs are generated with an expiry of at most 604800 seconds (7 days) and at least 3600 seconds.
6. THE `KlingWebhookHandlerFunction` SHALL validate that the `task_id` in the webhook payload maps to a known `SceneSegment` in DynamoDB before processing the callback.
7. THE `JobRecord` `image_count` SHALL be between 1 and 20 (inclusive); IF outside this range, THEN THE `Pipeline` SHALL reject the job at initialization.

---

### Requirement 12: Performance and Scalability

**User Story:** As a system operator, I want the pipeline to process jobs within acceptable time bounds and scale to handle concurrent image analysis, so that the POC demonstrates production-viable performance.

#### Acceptance Criteria

1. THE `ImageAnalysisFunction` SHALL process each image within a Lambda timeout of 60 seconds, accounting for Bedrock `InvokeModel` latency of 2–5 seconds per image.
2. THE `StorySequencingFunction` SHALL complete within a Lambda timeout of 90 seconds, accounting for a single Bedrock call latency of 5–10 seconds.
3. THE `VoiceoverGenerationFunction` SHALL complete within a Lambda timeout of 120 seconds, accounting for ElevenLabs TTS latency of 10–30 seconds for a 90-second script.
4. THE `VideoGenerationOrchestratorFunction` SHALL submit all Kling.ai tasks within a Lambda timeout of 30 seconds per task, with a total timeout sufficient for up to 20 segments.
5. THE `Pipeline` SHALL support up to 20 concurrent Kling.ai video generation tasks per job.
6. THE `KlingWebhookHandlerFunction` SHALL have a reserved Lambda concurrency of at least 50 to handle simultaneous webhook callbacks.
7. THE `DynamoDB` tables SHALL use on-demand capacity mode and maintain GSIs on `job_id` (for `property-video-images` and `property-video-stories`) and `kling_task_id` (for `property-video-stories`) to support efficient queries.
