# Implementation Plan: Kling AI Video POC

## Overview

Implement a 5-stage serverless pipeline in Python 3.12 that transforms real estate property photos into a finished MP4 showcase video. Each stage is a Lambda function decoupled via EventBridge, with DynamoDB tracking job state throughout. Implementation proceeds stage-by-stage, wiring each component into the event-driven backbone before moving to the next.

## Tasks

- [x] 1. Project structure, shared utilities, and data models
  - Create the top-level directory layout: `src/` with one subdirectory per Lambda function, `src/shared/` for common utilities, and `tests/` mirroring the source tree
  - Implement Python dataclasses for `JobRecord`, `ImageAnalysisResult`, `SceneSegment`, `StorySequence`, and `KlingWebhookPayload` in `src/shared/models.py`
  - Implement `parse_s3_key(key: str) -> tuple[str, str]` in `src/shared/utils.py` — raises `ValueError` for any key not matching `property_photos/{uuid-v4}/{filename}`
  - Implement a `StructuredLogger` helper in `src/shared/logger.py` that always includes `job_id`, stage name, and outcome in every CloudWatch log entry
  - Implement a `SecretsManagerClient` wrapper in `src/shared/secrets.py` with in-memory caching to avoid redundant API calls
  - Add `requirements.txt` with `boto3>=1.34`, `requests>=2.31`, `hypothesis>=6.0`, `pytest>=7.0`, `moto>=5.0`
  - _Requirements: 1.1, 1.4, 8.1, 9.2, 10.2, 11.1_

  - [ ]* 1.1 Write property test for `parse_s3_key` — invalid key always raises ValueError
    - **Property 8: S3 Key Pattern Validation**
    - **Validates: Requirements 1.4, 11.1**

  - [ ]* 1.2 Write unit tests for `parse_s3_key` valid and invalid inputs
    - Test correct extraction of `job_id` and `filename` from well-formed keys
    - Test `ValueError` raised for missing prefix, missing filename, non-UUID job_id

- [x] 2. DynamoDB table definitions and access layer
  - Implement `src/shared/dynamo.py` with typed helper functions for all three tables: `property-video-jobs`, `property-video-images`, `property-video-stories`
  - Implement `get_job`, `put_job`, `update_job_status`, and atomic `increment_images_analyzed` (using DynamoDB `ADD`) in the jobs access layer
  - Implement `put_image_result`, `query_images_by_job` (using `job_id-index` GSI) in the images access layer
  - Implement `put_story_sequence`, `get_story_by_job`, `update_segment_kling_fields`, `query_segments_by_job` (using `job_id-index` GSI), and `query_segment_by_task_id` (using `kling_task_id-index` GSI) in the stories access layer
  - Validate `image_count` is between 1 and 20 in `put_job`; raise `ValueError` if outside range
  - _Requirements: 1.2, 1.3, 1.5, 2.5, 2.6, 8.5, 10.7, 11.7, 12.7_

  - [ ]* 2.1 Write property test for atomic counter correctness
    - **Property 11: Atomic Counter Correctness**
    - **Validates: Requirements 2.6, 10.7**

  - [ ]* 2.2 Write unit tests for DynamoDB access layer using `moto`
    - Test `increment_images_analyzed` returns correct updated value
    - Test `query_images_by_job` returns all records for a job
    - Test `image_count` boundary validation (0, 1, 20, 21)

- [x] 3. Stage 1 — ImageAnalysisFunction
  - Implement `src/image_analysis/handler.py` with the main `handler(event, context)` function triggered by S3 ObjectCreated events
  - Implement image format validation (JPEG, PNG, WEBP only) and size check (reject > 10 MB) before invoking Bedrock
  - Implement `analyze_image(s3_key, job_id)` — downloads image bytes from S3, base64-encodes, invokes `anthropic.claude-3-5-sonnet-20241022-v2:0` via Bedrock, parses response into `ImageAnalysisResult`
  - Validate `composition_score` in [0.0, 1.0] and `key_selling_points` has at least one item; reject and halt if invalid
  - Implement `check_all_images_analyzed` and `emit_all_images_analyzed` — emit EventBridge event exactly once when `images_analyzed == image_count`
  - Implement partial batch failure response using `batchItemFailures` format for failed S3 records
  - Wire structured logger to emit `job_id`, `"image_analysis"`, and outcome on every invocation
  - _Requirements: 1.1, 1.4, 2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7, 2.8, 2.9, 10.2, 10.5, 10.7, 11.1, 11.2, 12.1_

  - [ ]* 3.1 Write property test for exactly-once completion detection
    - **Property 1: Image Analysis Exactly-Once Completion Detection**
    - **Validates: Requirements 2.7, 2.8**

  - [ ]* 3.2 Write property test for image size rejection
    - **Property 9: Image Size Rejection**
    - **Validates: Requirements 2.2**

  - [ ]* 3.3 Write property test for composition score validation
    - **Property 10: Composition Score Validation**
    - **Validates: Requirements 2.4**

  - [ ]* 3.4 Write property test for partial batch failure reporting
    - **Property 18: Partial Batch Failure Reporting**
    - **Validates: Requirements 10.5**

  - [ ]* 3.5 Write unit tests for ImageAnalysisFunction using `moto`
    - Test valid S3 event triggers Bedrock invocation and DynamoDB write
    - Test oversized image halts processing without calling Bedrock
    - Test unsupported image format halts processing
    - Test `batchItemFailures` response contains only failed record IDs

- [x] 4. Checkpoint — Stage 1 complete
  - Ensure all tests pass, ask the user if questions arise.

- [x] 5. Stage 2 — StorySequencingFunction
  - Implement `src/story_sequencing/handler.py` triggered by EventBridge `all-images-analyzed` event
  - Implement `sequence_images(image_metadata)` — invokes Bedrock with all image metadata, parses response into `StorySequence`
  - Implement `build_bedrock_prompt(image_metadata)` — constructs the story sequencing prompt including all `ImageAnalysisResult` fields
  - Validate `total_duration_seconds` in [60, 90]; validate segment count equals `image_count`; validate each `SceneSegment` has non-empty `script_text`, `video_prompt`, and a Kling.ai-supported `camera_movement`
  - Persist `StorySequence` to DynamoDB, update `JobRecord` status to `voiceover` and set `story_sequence_id`, emit `story-generated` EventBridge event
  - Wire structured logger
  - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5, 3.6, 3.7, 3.8, 8.3, 10.2, 11.3, 11.4, 12.2_

  - [ ]* 5.1 Write property test for story duration constraint
    - **Property 2: Story Duration Constraint**
    - **Validates: Requirements 3.3, 11.3**

  - [ ]* 5.2 Write property test for segment count matching image count
    - **Property 3: Segment Count Matches Image Count**
    - **Validates: Requirements 3.4**

  - [ ]* 5.3 Write property test for SceneSegment field completeness
    - **Property 12: SceneSegment Field Completeness**
    - **Validates: Requirements 3.5, 11.4**

  - [ ]* 5.4 Write unit tests for StorySequencingFunction using `moto`
    - Test valid EventBridge event triggers DynamoDB query and Bedrock invocation
    - Test invalid duration (< 60 or > 90) raises validation error
    - Test segment count mismatch raises validation error
    - Test `story-generated` event emitted with correct `job_id` and `story_id`

- [x] 6. Stage 3 — VoiceoverGenerationFunction
  - Implement `src/voiceover_generation/handler.py` triggered by EventBridge `story-generated` event
  - Implement `generate_voiceover(script, voice_id, api_key)` — POSTs to `https://api.elevenlabs.io/v1/text-to-speech/{voice_id}` with `eleven_multilingual_v2`, `stability=0.5`, `similarity_boost=0.75`, 90s timeout
  - Implement `upload_audio(audio_bytes, job_id)` — uploads MP3 to S3 assets bucket at `voiceovers/{job_id}/narration.mp3` with `ContentType: audio/mpeg`
  - Retrieve ElevenLabs API key and `voice_id` from Secrets Manager using secret ID `elevenlabs/api_key`
  - On ElevenLabs non-200 response: log error with `job_id` and status code, update `JobRecord` status to `failed`, halt
  - Update `JobRecord` with `voiceover_s3_key` and status `generating`; emit `voiceover-complete` EventBridge event
  - Wire structured logger
  - _Requirements: 4.1, 4.2, 4.3, 4.4, 4.5, 4.6, 4.7, 8.3, 9.1, 9.2, 10.2, 12.3_

  - [ ]* 6.1 Write unit tests for VoiceoverGenerationFunction using `moto` and `requests-mock`
    - Test successful ElevenLabs response uploads MP3 to correct S3 key
    - Test non-200 ElevenLabs response sets job status to `failed`
    - Test `voiceover-complete` event emitted with correct `voiceover_s3_key`

- [x] 7. Stage 4 — VideoGenerationOrchestratorFunction
  - Implement `src/video_generation/handler.py` triggered by EventBridge `voiceover-complete` event
  - Implement `generate_presigned_url(s3_key, expires)` — generates S3 GET presigned URL; validate expiry is in [3600, 604800]
  - Implement `submit_video_task(image_url, prompt, job_id, segment_index, api_key)` — POSTs to `https://api.kling.ai/v1/video/generate` with all required fields (`image_url`, `prompt`, `duration`, `aspect_ratio: 16:9`, `resolution: 1080p`, `mode: cinematic`, `camera_movement`, `webhook_url`); asserts HTTP 202 and non-null `task_id`
  - Implement `build_kling_payload(image_url, prompt, webhook_url)` — constructs the complete Kling.ai request payload
  - Retrieve Kling.ai API key from Secrets Manager; iterate all segments, store `kling_task_id` and set `kling_status=queued` per segment in DynamoDB
  - Wire structured logger
  - _Requirements: 5.1, 5.2, 5.3, 5.4, 5.5, 5.6, 9.1, 10.2, 11.5, 12.4, 12.5_

  - [ ]* 7.1 Write property test for Kling.ai payload completeness
    - **Property 13: Kling.ai Payload Completeness**
    - **Validates: Requirements 5.4**

  - [ ]* 7.2 Write property test for all segments having task IDs after orchestration
    - **Property 14: All Segments Have Task IDs After Orchestration**
    - **Validates: Requirements 5.6**

  - [ ]* 7.3 Write property test for presigned URL expiry bounds
    - **Property 15: Presigned URL Expiry Bounds**
    - **Validates: Requirements 5.3, 11.5**

  - [ ]* 7.4 Write unit tests for VideoGenerationOrchestratorFunction using `moto` and `requests-mock`
    - Test each segment receives a `kling_task_id` in DynamoDB after successful submission
    - Test presigned URL expiry outside [3600, 604800] raises `ValueError`
    - Test Kling.ai non-202 response raises exception and halts

- [x] 8. Checkpoint — Stages 1–4 complete
  - Ensure all tests pass, ask the user if questions arise.

- [x] 9. Stage 5 — KlingWebhookHandlerFunction
  - Implement `src/webhook_handler/handler.py` triggered by API Gateway POST `/webhook/kling`
  - Implement `validate_webhook_signature(payload, signature, secret)` — computes HMAC-SHA256 of raw body using stored secret; uses `hmac.compare_digest` for timing-safe comparison; returns `False` for missing or mismatched signature
  - On invalid/missing signature: return HTTP 401 and log warning with source IP
  - Implement `download_video_segment(video_url, job_id, segment_index)` — downloads video bytes from Kling CDN, uploads to S3 assets at `segments/{job_id}/{segment_index}.mp4`
  - Validate `task_id` maps to a known `SceneSegment` via `kling_task_id-index` GSI; reject without DynamoDB mutation if unknown
  - Implement `check_all_segments_complete(job_id)` — queries all segments for job; returns `True` only if all have `kling_status=complete`
  - On `status=completed`: download segment, update `SceneSegment` with `kling_status=complete` and `video_s3_key`, check completion, emit `all-segments-complete` if all done
  - On `status=failed`: update `SceneSegment` `kling_status=failed` and record `error_message`
  - Implement idempotency: re-processing the same `task_id` must produce identical DynamoDB state and must not emit duplicate `all-segments-complete` events
  - Always return HTTP 200 for any valid (signature-verified) webhook
  - Wire structured logger
  - _Requirements: 6.1, 6.2, 6.3, 6.4, 6.5, 6.6, 6.7, 6.8, 6.9, 6.10, 9.1, 9.5, 10.2, 11.6, 12.6_

  - [ ]* 9.1 Write property test for webhook idempotency
    - **Property 4: Webhook Idempotency**
    - **Validates: Requirements 6.10**

  - [ ]* 9.2 Write property test for all-segments-complete emitted exactly once
    - **Property 5: All-Segments-Complete Emitted Exactly Once**
    - **Validates: Requirements 6.7**

  - [ ]* 9.3 Write property test for invalid webhook signatures always rejected
    - **Property 6: Invalid Webhook Signatures Always Rejected**
    - **Validates: Requirements 6.1, 6.2, 9.5**

  - [ ]* 9.4 Write property test for segment S3 key naming convention
    - **Property 16: Segment S3 Key Naming Convention**
    - **Validates: Requirements 6.4**

  - [ ]* 9.5 Write property test for valid webhook always returns HTTP 200
    - **Property 17: Valid Webhook Always Returns HTTP 200**
    - **Validates: Requirements 6.9**

  - [ ]* 9.6 Write property test for unknown task ID rejection
    - **Property 20: Unknown Task ID Rejection**
    - **Validates: Requirements 11.6**

  - [ ]* 9.7 Write unit tests for KlingWebhookHandlerFunction using `moto` and `requests-mock`
    - Test valid HMAC + `status=completed` stores segment in S3 and updates DynamoDB
    - Test invalid HMAC returns 401 with no DynamoDB mutations
    - Test `status=failed` sets `kling_status=failed` and records `error_message`
    - Test idempotent re-processing of same `task_id` produces no duplicate events
    - Test unknown `task_id` returns 400 with no DynamoDB mutations

- [x] 10. Job status monotonicity enforcement
  - Add a `safe_update_job_status(job_id, expected_current, new_status)` function in `src/shared/dynamo.py` using a DynamoDB conditional expression to prevent status regression
  - Wire `safe_update_job_status` into all Lambda handlers that advance job status: `ImageAnalysisFunction` (→ `sequencing`), `StorySequencingFunction` (→ `voiceover`), `VoiceoverGenerationFunction` (→ `generating`), `VideoGenerationOrchestratorFunction` (→ `assembling`), `AssemblyWorkflow` (→ `complete`)
  - Allow unconditional transition to `failed` from any state
  - _Requirements: 8.1, 8.2, 8.3, 8.4_

  - [ ]* 10.1 Write property test for job status monotonicity
    - **Property 7: Job Status Monotonicity**
    - **Validates: Requirements 8.1, 8.2, 8.4**

  - [ ]* 10.2 Write unit tests for `safe_update_job_status`
    - Test valid forward transition succeeds
    - Test backward transition raises `ConditionalCheckFailedException`
    - Test transition to `failed` succeeds from any state

- [x] 11. Step Functions assembly workflow
  - Implement the Step Functions state machine definition (`src/assembly/state_machine.json` or CDK/CloudFormation) with states: retrieve segments → assemble video → update job complete
  - Implement `src/assembly/retrieve_segments.py` Lambda — queries DynamoDB for all segment S3 keys ordered by `segment_index`
  - Implement `src/assembly/assemble_video.py` Lambda — concatenates video segments from S3 assets into a single MP4 and stores in `S3_Output`
  - Implement `src/assembly/finalize_job.py` Lambda — updates `JobRecord` with `status=complete` and `final_video_s3_key`; on failure, sets `status=failed` and `error_message`
  - Wire the `all-segments-complete` EventBridge event to trigger Step Functions `StartExecution`
  - _Requirements: 7.1, 7.2, 7.3, 7.4, 7.5, 8.3_

  - [ ]* 11.1 Write unit tests for assembly Lambda functions using `moto`
    - Test `retrieve_segments` returns keys in correct `segment_index` order
    - Test `finalize_job` sets `status=complete` and `final_video_s3_key`
    - Test `finalize_job` sets `status=failed` on assembly error

- [x] 12. Infrastructure as code — IAM roles and Secrets Manager
  - Define a dedicated IAM role for each Lambda function with least-privilege policies (no wildcard actions)
  - Define Secrets Manager secrets for `elevenlabs/api_key` (with `api_key` and `voice_id` fields) and `kling/api_key` and `kling/webhook_secret`
  - Enable 90-day rotation policy on all Secrets Manager secrets
  - _Requirements: 9.1, 9.2, 9.3, 9.7_

- [x] 13. Infrastructure as code — S3 buckets, DynamoDB tables, EventBridge, and API Gateway
  - Define three S3 buckets (`realestate-video-input`, `realestate-video-assets`, `realestate-video-output`) with all public access blocked
  - Define three DynamoDB tables in on-demand capacity mode with TTL on `property-video-jobs`, and GSIs: `job_id-index` on `property-video-images` and `property-video-stories`, `kling_task_id-index` on `property-video-stories`
  - Define EventBridge custom event bus with rules routing `all-images-analyzed` → `StorySequencingFunction`, `story-generated` → `VoiceoverGenerationFunction`, `voiceover-complete` → `VideoGenerationOrchestratorFunction`, `all-segments-complete` → Step Functions
  - Define API Gateway REST API with POST `/webhook/kling` route wired to `KlingWebhookHandlerFunction`; attach AWS WAF with rate limiting and IP-based blocking rules
  - Configure EventBridge retry policy (3 retries, exponential backoff) and DLQ for each Lambda event source; add CloudWatch alarm on DLQ message count
  - Configure `KlingWebhookHandlerFunction` reserved concurrency to at least 50
  - Enable X-Ray active tracing on all Lambda functions
  - _Requirements: 9.4, 9.6, 10.1, 10.3, 10.4, 12.6, 12.7_

- [x] 14. Checkpoint — Full pipeline wired end-to-end
  - Ensure all tests pass, ask the user if questions arise.

- [x] 15. Structured logging and observability wiring
  - Verify every Lambda handler emits structured logs with `job_id`, stage name, and outcome on every code path (success, validation failure, external API error)
  - Add X-Ray subsegment annotations for Bedrock, ElevenLabs, and Kling.ai calls (no PII or API keys in annotations)
  - _Requirements: 9.2, 10.1, 10.2_

  - [ ]* 15.1 Write property test for structured log fields
    - **Property 19: Structured Log Fields**
    - **Validates: Requirements 10.2**

- [x] 16. Final checkpoint — All tests pass
  - Ensure all tests pass, ask the user if questions arise.

## Notes

- Tasks marked with `*` are optional and can be skipped for faster MVP
- All Lambda functions use Python 3.12
- Property tests use `hypothesis`; unit tests use `pytest` + `moto`
- Each task references specific requirements for traceability
- Checkpoints ensure incremental validation at each major stage boundary
- Property tests validate universal correctness properties (Properties 1–20 from design)
- Unit tests validate specific examples and edge cases
