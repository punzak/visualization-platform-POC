# Video generation provider implementations
